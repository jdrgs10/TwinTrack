# TwinTrack final locked UI reference

This is the GitHub/Sunday implementation package for the locked TwinTrack UI. It is a native SwiftUI reference, not code to copy literally.

## Authority order

1. `Screenshots/Home/Home_Light_FINAL.png` is the final authoritative Home visual.
2. `Screenshots/Non-Home/` contains the unchanged approved TwinTrack AI, Profile, detail-page, sheet, light/dark, and shared-TabBar captures.
3. `Source/` contains the active final HTML/component files and clean logo assets for exact colors, spacing, structure, lower/cropped states, and appearance parity.
4. `TwinTrack_UI_Handoff.md` contains the locked SwiftUI implementation guidance and project-behavior requirements.

## Home supersession

The package intentionally excludes these obsolete Home captures:

- `Screenshot 2026-09-05 034006.png`
- `Screenshot 2026-09-05 034040.png`
- `Screenshot 2026-09-05 034048.png`

They predate the locked non-ranking Model Insight wording and must not be used. The final Home image was copied without modification from `Screenshot 2026-09-05 042526.png` and renamed `Home_Light_FINAL.png` so its authority is unambiguous. Use `Source/TwinTrack Home.dc.html` for lower-page content and dark-mode parity; do not revive an excluded Home screenshot.

## Coverage

- Final Home top reference
- TwinTrack AI light/dark conversations, deterministic What-If results, explanations, composer, and adjustment controls
- Profile light/dark upper and lower views
- Edit Profile and Manual Inputs sheets
- Health Permissions, Data & Privacy, Prediction Methodology, Model Information, About, Privacy Policy, and Prediction Disclaimer references
- Remaining source-defined Profile pages/states, including Terms of Use and Appearance
- Shared TabBar component and light/dark states
- Final transparent dark/light emblem assets and full logo lockup

The export-dialog screenshot and standalone logo proof screenshot are not app screens and are excluded. The actual logo PNG files are provided in `Source/assets/`.

## Implementation rule

Do not port mock equations, mock trends, hard-coded preview values, or literal HTML layout behavior into the production app. Implement the approved appearance natively in SwiftUI and follow `TwinTrack_UI_Handoff.md` for data, HealthKit, Ridge, Foundation Models, accessibility, and missing-state behavior.
