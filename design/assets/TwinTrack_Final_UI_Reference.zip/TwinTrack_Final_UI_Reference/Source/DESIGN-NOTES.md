# TwinTrack AI — design notes (prototype)

**EXTERNAL AI DRAFT — REQUIRES XCODE VALIDATION.** All names, connection states, permissions, dates and numbers in these screens are preview/mockup values. Nothing has been compiled, connected to HealthKit, or validated on device.

## Files
- `TwinTrack Home.dc.html` — Home
- `TwinTrack AI.dc.html` — TwinTrack AI (chat + deterministic What-If)
- `Profile.dc.html` — Profile + all detail pages and sheets
- `TabBar.dc.html` — the single shared bottom tab bar used by all three screens

## Assets
| File | Size | Use |
| --- | --- | --- |
| `assets/twintrack-mark-sm.png` | 204×103, alpha | Dark header emblem (approved, unchanged) |
| `assets/twintrack-mark-sm-light.png` | 204×103, alpha | **Light header emblem** — transparent, emblem only, aspect preserved, centred in the same 204×103 frame as the dark asset |
| `assets/twintrack-mark-light-2x.png` | 408×206, alpha | 2× light emblem (downsampled from the 3×, alpha preserved) |
| `assets/twintrack-mark-light-3x.png` | 612×309, alpha | 3× light emblem for the asset catalog |
| `assets/twintrack-mark.png` | 716×360, alpha | Higher-resolution dark emblem source |
| `assets/twintrack-logo-full.png` | 1024×1024, alpha | Full dark lockup, branding only |

Light emblem provenance: derived from the user-supplied `uploads/twintrack white logo.png` by un-matting the opaque near-white plate (per-pixel alpha recovered, original ink colours restored) and cropping to the emblem. No redraw, no recolour, no blend mode, no crop workaround, no box, border, shadow or glow. Header renders `width:68px; height:34px; object-fit:contain` in both appearances.

Asset-catalog contract: image set `TwinTrackHeaderMark`, Any/Dark = dark emblem, Light = light emblem, 68×34 frame, `.fit`, decorative.

## Bottom navigation
One shared component (`TabBar.dc.html`), mounted with `active="home" | "ai" | "profile"`. Identical filled glyph, 23×23 frame, 11 px top offset and 4 px icon→label gap in every state. Selection changes colour and label weight only — icon `--acc`, label `--accLabel`, inactive `--tx2`. Maps to one native `TabView`.

## Final colour tokens (after contrast corrections)
| Token | Dark | Light |
| --- | --- | --- |
| `pageBg` (preview canvas only) | `#0a0e15` | `#E7EBF1` |
| `bg` | `#070B12` | `#F1F4F8` |
| `card` | `rgba(255,255,255,.028)` | `#FFFFFF` |
| `card2` | `rgba(255,255,255,.045)` | `#FFFFFF` |
| `bd` | `rgba(255,255,255,.055)` | `#DDE3EC` |
| `bd2` | `rgba(255,255,255,.07)` | `#D3DAE6` |
| `hover` (web only) | `rgba(255,255,255,.03)` | `#F5F7FA` |
| `tx` | `#F2F4F7` | `#0F1B2D` |
| `tx2` | `rgba(226,235,250,.5)` | `#5A6B82` |
| `tx3` **(corrected)** | `rgba(226,235,250,.5)` | `#607087` |
| `tx4` (new, decorative marks only) | `rgba(226,235,250,.3)` | `#93A1B5` |
| `hero` | `#EAF6FD` | `#0B2033` |
| `acc` | `#5AC8F0` | `#0E7FB8` |
| `accTx` | `#9BD6F3` | `#0B6E9E` |
| `accLabel` (new, selected tab label) | `#5AC8F0` | `#0B6E9E` |
| `accBg` | `rgba(90,200,240,.06)` | `#E9F4FB` |
| `accBd` | `rgba(122,197,240,.2)` | `#C3DEEF` |
| `accStrong` **(corrected)** | `#1976B8` | `#0B6E9E` |
| `onAcc` | `#F4FBFF` | `#FFFFFF` |
| `onAccDim` | `rgba(244,251,255,.7)` | `rgba(255,255,255,.85)` |
| `bar` | `rgba(90,200,240,.26)` | `#BEDDF0` |
| `vio` | `#9A8FF0` | `#5B4BC4` |
| `vioTx` | `rgba(178,168,245,.85)` | `#5044B0` |
| `vioBg` | `rgba(139,127,232,.06)` | `#F2F0FD` |
| `vioBd` | `rgba(139,127,232,.16)` | `#DAD4F6` |
| `grn` **(light corrected)** | `#34C77B` | `#187A46` |
| `grnBg` | `rgba(52,199,123,.12)` | `#E4F5EB` |
| `amb` | `#E3A23C` | `#9A6608` |
| `ambTx` | `rgba(235,203,146,.9)` | `#7A5205` |
| `ambBg` | `rgba(227,162,60,.07)` | `#FCF3E4` |
| `ambBd` | `rgba(227,162,60,.2)` | `#EDD8AE` |
| `onWarn` (new, Draft badge) | `#0B2033` | `#FFFFFF` |
| `red` (destructive) | `#D9736E` | `#B3423C` |
| `disFg` (new, disabled foreground) | `rgba(226,235,250,.45)` | `#8794A6` |
| `navBg` | `rgba(7,11,18,.82)` | `rgba(241,244,248,.88)` |
| `userBub` **(light corrected)** | `#1F4E72` | `#0B6E9E` |
| `userTx` | `#EAF6FD` | `#FFFFFF` |
| `sheet` | `#141A24` | `#FFFFFF` |
| `scrim` | `rgba(0,0,0,.55)` | `rgba(15,27,45,.3)` |

No gradients anywhere. Token strings are byte-identical across all four files.

## Appearance
Profile → Appearance sets System / Light / Dark, persisted under `tt-theme`; all three screens follow it, and each exposes an Appearance tweak for review. Light and dark are one markup tree with two token sets — no duplicated screen files.

## Model-accuracy rules honoured in the copy
- Ridge Regression produces every predicted score and every What-If number; frozen, on-device.
- Apple Foundation Models interprets requests and explains returned results. It never calculates, estimates or edits a number.
- Relationships are described as predictive, not causal. No confidence percentages, accuracy statistics or coefficients. No screen claims a feature ranking — the prototype's mock coefficients are never used to assert which input matters most.
- HealthKit language never claims read authorisation: Home shows `Apple Health`; Profile shows `Recent data available`; Health Permissions lists `Included in access request`; unavailable HealthKit values read `No accessible recent value`; un-entered manual values read `Not entered`. Zeroes are never substituted.
- Privacy Policy, Terms of Use and Prediction Disclaimer carry a visible **Draft** banner.
- `Clear Prediction History` renders in the destructive red role; SwiftUI adds `role: .destructive` plus confirmation.
- The 7-day trend, prediction history and all numeric values are preview data for layout only.
